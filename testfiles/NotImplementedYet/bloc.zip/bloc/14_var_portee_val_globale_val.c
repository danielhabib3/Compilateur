int main()
{
    int a;
    a=4;
    {
        a=2;
        {
            a=3;
        }
    }

    return a;
}