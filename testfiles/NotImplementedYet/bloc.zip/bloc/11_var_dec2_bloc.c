int main()
{
    int a;
    {
        int a;
        {
            int a;
            {
                
            }
            int a;
        }
    }
    return 0;
}