int main()
{
    int a;
    {
        int b;
        {
            int c;
        }
    }
    return 0;
}